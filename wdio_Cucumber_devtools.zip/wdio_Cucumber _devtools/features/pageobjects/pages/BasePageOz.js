'use strict';

const HeaderOz = require('../components/HeaderOz');
const FooterOz = require('../components/FooterOz');

class BasePageOz {
        constructor() {
                
                this.HeaderOz = new HeaderOz();
                this.FooterOz = new FooterOz();
        };

}

module.exports =  BasePageOz;
