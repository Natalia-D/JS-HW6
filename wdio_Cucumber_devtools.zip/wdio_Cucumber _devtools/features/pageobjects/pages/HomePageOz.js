const BasePageOz = require('./BasePageOz');

/**
 * sub page containing specific selectors and methods for a specific page
 */
class HomePageOz extends BasePageOz {

    constructor() {
        super()
    }
   
    get MenuOz  () {return (".main-nav__list")};


    get MenuItems() { return `${this.MenuOz} > li>a`};
    
    
}

module.exports = HomePageOz ;
