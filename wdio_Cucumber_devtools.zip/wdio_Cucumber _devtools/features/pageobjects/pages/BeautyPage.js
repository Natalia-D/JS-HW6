const BasePageOz = require('./BasePageOz');

/**
 * sub page containing specific selectors and methods for a specific page
 */
class BeautyPage extends BasePageOz {

    constructor() {
        super()
    }
   
    get BeautyHeader  () {return (".landing__header")};

    get BeautyTitle () {return `${this.BeautyHeader} > section > div.landing-header__line.landing-header__line_top > h1 `};

    get BeautyForm  () {return ("#fform")};


    get Parfume () {return "div.filters__group li:not(li:nth-child(1))>a>span"}

    get BreadcrumbsElement () {return "//div[@class='breadcrumbs__outer']/div/ul[2]/li[3]/h1/span"}
    

   

}

module.exports = BeautyPage ;
