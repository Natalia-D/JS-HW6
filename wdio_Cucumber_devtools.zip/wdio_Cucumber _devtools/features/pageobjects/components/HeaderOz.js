'use strict';

class HeaderOz {
        constructor() {

        };
        get Beauty() { return "ul.main-nav__list >li:nth-child(3)>a" }
       

		

}

module.exports = HeaderOz;