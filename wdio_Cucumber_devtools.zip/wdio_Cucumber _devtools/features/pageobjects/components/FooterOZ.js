'use strict';

class FooterOz {
        constructor() {

        };
        
        get FirstBlock  () {return ("div.footer-full__nav>ul:nth-child(1)")};


        get Delivery() { return `${this.FirstBlock} > li:nth-child(2) > a` }
       

	

}

module.exports = FooterOz;