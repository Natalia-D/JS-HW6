

const { Given, When, Then } = require('@wdio/cucumber-framework');



Given('User navigates to {landing-url}', function (url) {
    const currentUrl = browser.executeScript("return document.URL;");
    // maybe we are already there?
    if (currentUrl !== url) {
      return browser.url(url);
    }
  });
  


When(`I click {locator} element`, async (element) => {
  await  browser.execute("document.querySelector('"+element+"').style.backgroundColor = '" + "green" + "'")
  // await $(element).click();
  await browser.execute("document.querySelector('"+element+"').click();")

   
});

When('I sleep {int} second(s)', async (number) => {
    let seconds = parseFloat(number);
    return await browser.pause(Math.floor(seconds * 1000));
});


When('I scroll down', async () => {
  await browser.execute('window.scrollTo(0, document.body.scrollHeight)');
});

When('I scroll to {locator} element', async (el) => {
  await el.location_once_scrolled_into_view
  //await browser.execute( "arguments[0].scrollIntoView();", el);

  
});





