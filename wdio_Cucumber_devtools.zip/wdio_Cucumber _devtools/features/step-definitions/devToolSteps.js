const { Given, When, Then } = require('@wdio/cucumber-framework');




When('DevTools check network on {landing-url}', async (serviceUri) => {

  browser.cdp('Network', 'enable');
  browser.on('Network.responseReceived', (params) => {
    if ((params.response.url.startsWith('https://www.google-analytics.com'))) {
      console.log(`Loaded ${params.response.url}`)
    }
    if (!(params.response.status === 200)) {
      console.log(`${params.response.url} ${params.response.status}`)

      browser.cdp('Network', 'getResponseBody', {
        requestId: params.requestId
      }).then((res) => {
        console.log(res);
      });
    }
  });
  await browser.url(serviceUri);



});

When('DevTools check performance on {landing-url}', async (serviceUri) => {
  await browser.enablePerformanceAudits({
    networkThrottling:'Good 3G',
    cpuThrottling:4,
    cashEnabled: true,
    formFactor: 'mobile'
  })
   await browser.emulateDevice('iPad Mini')
   await browser.url(serviceUri);

  // await browser.getMetrics();

   await browser.disablePerformanceAudits()

});

